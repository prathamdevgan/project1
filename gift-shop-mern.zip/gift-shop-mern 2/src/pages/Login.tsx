import { Button } from "@/components/ui/button";
import { Gift } from "lucide-react";

export default function Login() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)]">
      <div className="w-full max-w-md space-y-8 text-center">
        <div className="space-y-4">
          <Gift className="mx-auto h-12 w-12" />
          <h2 className="text-3xl font-bold">Welcome to Gift Shop</h2>
          <p className="text-muted-foreground">
            Sign in to manage your gift listings and explore our collection
          </p>
        </div>

        <div className="space-y-4">
          <a href="http://localhost:4000/auth/google">
            <Button className="w-full" size="lg">
              Continue with Google
            </Button>
          </a>
        </div>
      </div>
    </div>
  );
}
