import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import GiftForm, { IGift } from "@/components/GiftForm";
import GiftCard from "@/components/GiftCard";
import { useToast } from "@/components/ui/use-toast";
import { Loading } from "@/components/ui/loading";

export default function Dashboard() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [gifts, setGifts] = useState<IGift[]>([]);
  const [selectedGift, setSelectedGift] = useState<IGift | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isLoadingGifts, setIsLoadingGifts] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      navigate("/login");
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    const fetchGifts = async () => {
      if (!user) return;

      setIsLoadingGifts(true);
      try {
        const { data } = await axios.get("http://localhost:4000/api/gifts", {
          withCredentials: true,
        });
        setGifts(data);
      } catch (error) {
        console.error("Error fetching gifts:", error);
        toast({
          title: "Error",
          description: "Failed to fetch gifts",
          variant: "destructive",
        });
      } finally {
        setIsLoadingGifts(false);
      }
    };

    fetchGifts();
  }, [user, toast]);

  const handleDelete = async (id: string) => {
    try {
      await axios.delete(`http://localhost:4000/api/gifts/${id}`, {
        withCredentials: true,
      });
      setGifts(gifts.filter((gift) => gift._id !== id));
      toast({
        title: "Success",
        description: "Gift deleted successfully",
      });
    } catch (error) {
      console.error("Error deleting gift:", error);
      toast({
        title: "Error",
        description: "Failed to delete gift",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loading size="lg" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">My Gifts</h1>
        <Button onClick={() => setIsFormOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Add Gift
        </Button>
      </div>

      <GiftForm
        open={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setSelectedGift(null);
        }}
        selectedGift={selectedGift}
        onSuccess={(newGift) => {
          if (selectedGift) {
            const updatedGifts = gifts.map((gift) => {
              if (gift._id === selectedGift._id) {
                return newGift;
              }
              return gift;
            });
            setGifts(updatedGifts);
            setSelectedGift(null);
            setIsFormOpen(false);
            return;
          }
          setGifts([newGift, ...gifts]);
          setIsFormOpen(false);
        }}
      />

      {isLoadingGifts ? (
        <Loading />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {gifts.map((gift) => (
            <GiftCard
              key={gift._id}
              gift={gift}
              onDelete={handleDelete}
              isOwner={gift.createdBy._id === user._id}
              onEdit={(gift) => {
                setSelectedGift(gift);
                setIsFormOpen(true);
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
