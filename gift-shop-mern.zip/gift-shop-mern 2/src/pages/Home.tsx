import { Gift, Package, ShieldCheck, Truck } from 'lucide-react';

export default function Home() {
  return (
    <div className="space-y-16">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Welcome to Gift Shop</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Discover unique and thoughtful gifts for every occasion. From handcrafted items to luxury presents,
          we have something special for everyone.
        </p>
      </section>

      <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {features.map((feature) => (
          <div
            key={feature.title}
            className="p-6 border rounded-lg space-y-3 text-center"
          >
            <feature.icon className="w-12 h-12 mx-auto text-primary" />
            <h3 className="font-semibold">{feature.title}</h3>
            <p className="text-muted-foreground">{feature.description}</p>
          </div>
        ))}
      </section>

      <section className="text-center space-y-4">
        <h2 className="text-3xl font-bold">Start Shopping Today</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Join our community of gift enthusiasts and start discovering amazing presents
          for your loved ones.
        </p>
      </section>
    </div>
  );
}

const features = [
  {
    title: "Unique Gifts",
    description: "Carefully curated selection of unique and meaningful gifts",
    icon: Gift
  },
  {
    title: "Quality Assured",
    description: "Every item is checked for quality and authenticity",
    icon: ShieldCheck
  },
  {
    title: "Fast Shipping",
    description: "Quick and reliable shipping to your doorstep",
    icon: Truck
  },
  {
    title: "Gift Wrapping",
    description: "Professional gift wrapping service available",
    icon: Package
  }
];