import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Pencil } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { IGift } from "./GiftForm";

interface GiftCardProps {
  gift: IGift;
  onDelete: (id: string) => void;
  onEdit: (gift: IGift) => void;
  isOwner: boolean;
}

export default function GiftCard({
  gift,
  onDelete,
  isOwner,
  onEdit,
}: GiftCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="aspect-w-16 aspect-h-9 mb-4">
          <img
            src={gift.imageUrl}
            alt={gift.name}
            className="rounded-lg object-cover w-full h-48"
          />
        </div>
        <CardTitle>{gift.name}</CardTitle>
        <CardDescription>{gift.category}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">{gift.description}</p>
        <p className="mt-2 text-lg font-semibold">${gift.price.toFixed(2)}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <p className="text-sm text-muted-foreground">
          Added by {gift.createdBy.displayName}
        </p>
        <div className="flex items-center gap-3">
          <Button variant="default" size="icon" onClick={() => onEdit(gift)}>
            <Pencil className="h-4 w-4" />
          </Button>
          {isOwner && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="icon">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Gift</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete this gift? This action
                    cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => onDelete(gift._id)}>
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}
