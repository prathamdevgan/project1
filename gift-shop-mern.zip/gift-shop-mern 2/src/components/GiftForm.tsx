import { useEffect, useState } from "react";
import axios from "axios";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { DialogDescription } from "@radix-ui/react-dialog";

const giftSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
  price: z.number().min(0, "Price must be positive"),
  imageUrl: z.string().url("Must be a valid URL"),
  category: z.string().min(1, "Category is required"),
});

export interface IGift {
  _id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  createdBy: {
    _id: string;
    displayName: string;
  };
}

type GiftFormData = z.infer<typeof giftSchema>;

interface GiftFormProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (gift: IGift) => void;
  selectedGift?: IGift | null;
}

export default function GiftForm({
  open,
  onClose,
  onSuccess,
  selectedGift,
}: GiftFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
  } = useForm<GiftFormData>({
    defaultValues: selectedGift || {
      category: "",
      description: "",
      imageUrl: "",
      name: "",
      price: undefined,
    },
    resolver: zodResolver(giftSchema),
  });

  // Update form values with selectedGift on open
  useEffect(() => {
    if (selectedGift) {
      setValue("name", selectedGift.name);
      setValue("description", selectedGift.description);
      setValue("price", selectedGift.price);
      setValue("imageUrl", selectedGift.imageUrl);
      setValue("category", selectedGift.category);
    }
  }, [selectedGift, setValue]);

  const onSubmit = async (data: GiftFormData) => {
    setIsSubmitting(true);
    try {
      const url = selectedGift
        ? `http://localhost:4000/api/gifts/${selectedGift._id}`
        : "http://localhost:4000/api/gifts";
      const method = selectedGift ? "put" : "post"; // Use put for edits
      const response = await axios({
        method,
        url,
        data,
        withCredentials: true,
      });
      onSuccess(response.data);
      toast({
        title: "Success",
        description: selectedGift
          ? "Gift edited successfully"
          : "Gift added successfully",
      });
    } catch (error) {
      console.error(
        selectedGift ? "Error editing gift" : "Error adding gift",
        error
      );
      toast({
        title: "Error",
        description: selectedGift
          ? "Failed to edit gift"
          : "Failed to add gift",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
      reset();
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={() => {
        onClose();
        reset();
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {selectedGift ? "Edit Gift" : "Add New Gift"}
          </DialogTitle>
          <DialogDescription className="sr-only">
            gift form card
          </DialogDescription>
        </DialogHeader>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="space-y-4 rounded-lg"
        >
          <div>
            <Label htmlFor="name">Name</Label>
            <Input {...register("name")} placeholder="Gift name" />
            {errors.name && (
              <p className="text-sm text-red-500">{errors.name.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea {...register("description")} placeholder="Description" />
            {errors.description && (
              <p className="text-sm text-red-500">
                {errors.description.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="price">Price</Label>
            <Input
              {...register("price", { valueAsNumber: true })}
              type="number"
              step="0.01"
              placeholder="Price"
            />
            {errors.price && (
              <p className="text-sm text-red-500">{errors.price.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="imageUrl">Image URL</Label>
            <Input {...register("imageUrl")} placeholder="Image URL" />
            {errors.imageUrl && (
              <p className="text-sm text-red-500">{errors.imageUrl.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="category">Category</Label>
            <Input {...register("category")} placeholder="Category" />
            {errors.category && (
              <p className="text-sm text-red-500">{errors.category.message}</p>
            )}
          </div>

          <div className="flex justify-end space-x-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {selectedGift && !isSubmitting && "Edit Gift"}
              {isSubmitting ? "Adding..." : selectedGift && "Add Gift"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
