import { Link, useMatch } from "react-router-dom";
import { Gift } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();

  const islogin = useMatch("/login");
  const isDashboard = useMatch("/dashboard");

  const handleLogout = async () => {
    await logout();
  };

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <Gift className="h-6 w-6" />
          <span className="text-xl font-bold">Gift Shop</span>
        </Link>

        <div className="flex items-center space-x-4">
          {user ? (
            <>
              {!isDashboard && (
                <Link to="/dashboard">
                  <Button variant="ghost">Dashboard</Button>
                </Link>
              )}

              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
              <img
                src={user.avatar}
                alt={user.displayName}
                className="w-8 h-8 rounded-full"
              />
            </>
          ) : (
            !islogin && (
              <Link to="/login">
                <Button>Login</Button>
              </Link>
            )
          )}
        </div>
      </div>
    </nav>
  );
}
