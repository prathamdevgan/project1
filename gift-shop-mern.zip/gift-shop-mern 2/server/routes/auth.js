import express from "express";
import passport from "passport";

const router = express.Router();

router.get(
  "/google",
  passport.authenticate("google", { scope: ["profile", "email"] })
);

router.get(
  "/google/callback",
  passport.authenticate("google", {
    successRedirect: "http://localhost:5173/dashboard",
    failureRedirect: "http://localhost:5173/login",
  })
);

router.get("/user", (req, res) => {
  res.json(req.user || null);
});

router.get("/logout", (req, res) => {
  res.clearCookie("connect.sid");
  res.json({ status: "success", message: "Logout successful" });
});

export default router;
