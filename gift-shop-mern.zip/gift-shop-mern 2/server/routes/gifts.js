import express from "express";
import mongoose from "mongoose";
import Gift from "../models/Gift.js";

const router = express.Router();

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: "Unauthorized" });
};

// Get all gifts
router.get("/", async (req, res) => {
  try {
    const gifts = await Gift.find().populate("createdBy", "displayName");
    res.json(gifts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create a new gift
router.post("/", isAuthenticated, async (req, res) => {
  try {
    const gift = new Gift({
      ...req.body,
      createdBy: req.user._id,
    });
    await (await gift.save()).populate("createdBy", "displayName");

    res.status(201).json(gift);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update a gift
router.put("/:id", isAuthenticated, async (req, res) => {
  try {
    const gift = await Gift.findOneAndUpdate(
      { _id: req.params.id, createdBy: req.user._id },
      req.body,
      { new: true }
    ).populate("createdBy", "displayName");
    if (!gift) {
      return res.status(404).json({ error: "Gift not found or unauthorized" });
    }
    res.json(gift);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete a gift
router.delete("/:id", isAuthenticated, async (req, res) => {
  try {
    const gift = await Gift.findOneAndDelete({
      _id: req.params.id,
      createdBy: req.user._id,
    });
    if (!gift) {
      return res.status(404).json({ error: "Gift not found or unauthorized" });
    }
    res.json({ message: "Gift deleted successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
